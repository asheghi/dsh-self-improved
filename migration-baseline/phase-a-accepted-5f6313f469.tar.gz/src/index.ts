/**
 * dsh-self-improved — DeepSeek Harness long-term memory and self-evolution plugin (fully local).
 *
 * M1 status: memory store (SQLite + FTS5 + sqlite-vec skeleton) + L0 capture persistence + memory/conversation search tools.
 * Design docs live in docs/ (design/ and research/).
 */
import z from "@deepseek-ai/schemastery";
import type { Context, Volatile } from "@deepseek-ai/cordis";

// Service type augmentation: pull the `declare module '@deepseek-ai/cordis'` type augmentations from the dsh-* packages into this compilation.
import "@deepseek-ai/dsh-session";
import "@deepseek-ai/dsh-agent";
import type {} from "@deepseek-ai/dsh-agent-default-model";
import "@deepseek-ai/dsh-system-prompt";
import "@deepseek-ai/dsh-llm";
import "@deepseek-ai/dsh-schedule";
import "@deepseek-ai/dsh-session-query";
import "@deepseek-ai/dsh-settings";

import { MemoryStore, defaultMemoryDir } from "./storage.js";
import { BlockAssembler, createUserMessage } from "@deepseek-ai/dsh-llm";
import type { GenerateOptions } from "@deepseek-ai/dsh-llm";
import type { Context as CordisContext } from "@deepseek-ai/cordis";
import { evaluateTerminalFinish } from "./compat-v02.js";
import { installCapture, projectKeyFromCwd } from "./capture.js";
import { closeStalePendingEpisodes, repairEpisodeConsistency, assembleSessionEpisodes } from "./episodes.js";
import { EpisodeReviewAbortGate, runEpisodeReview } from "./episode-review.js";
import type { EpisodeReviewSummary } from "./episode-review.js";
import { registerMemoryTools } from "./tools.js";
import { Extractor, type ExtractSettings } from "./extract.js";
import { RecallService, createOpenAiEmbedding, renderCuratedProfile, type RecallSettings } from "./recall.js";
import { installRecallInjection } from "./inject.js";
import { Consolidator } from "./consolidate.js";
import { applyDecay, synthesizeSkills, synthesizeSkillsFromEpisodes, deleteSkill } from "./evolve.js";
import { installMemoryCommands, installBrowserChannel } from "./commands.js";
import { readValue, assignPlainTree } from "./runtime-config.js";
import { createMemoryBusiness, registerMemoryBusinessRemote } from "./business.js";
// Phase A shutdown boundary (bounded safe close of accepted work) lives in
// src/shutdown-v02.ts; owned deadline-cancellation signals are united with
// each lane's own per-call timeout signal through combineAbortSignals.
import { combineAbortSignals, registerShutdownDrain } from "./shutdown-v02.js";
// rc.2 augmentations for the loader-owned events this plugin subscribes to
// (the volatile settings hook) — side-effect import only.
import "@deepseek-ai/cordis-plugin-loader";
import type { BrowserChannel } from "./commands.js";
export const name = "self-improved";

/** Required host services (Cordis inject list; M1 adds sessionQuery for conversation full-text search) */
export const inject = ["sessions", "settings", "tools", "sessionQuery", "llm", "systemPrompt"] as const;

/** Module switches (see docs/design/dsh-memory-detailed-design.md §2.5 for coupling rules) */
export interface ModuleSwitches {
  capture: boolean;
  extract: boolean;
  consolidate: boolean;
  evolve: boolean;
  recall: boolean;
  tools: boolean;
}

export interface ExtractConfig {
  /** Polling interval in minutes */
  intervalMinutes: number;
  /** Max input characters per extraction batch */
  batchMaxChars: number;
  maxOutputTokens: number;
  timeoutMs: number;
  /** Deduplicate */
  dedup: boolean;
  /** Fall back to summarizing the raw text on bad JSON (off by default to avoid low-value summary noise) */
  fallbackOnBadJson: boolean;
  /** Drop extracted results whose importance is below this value (noise reduction, high floor = extraction is a privilege) */
  minImportance: number;
  /** headless: drain extraction synchronously on flush */
  flushDrain: boolean;
  /** Extraction model (leave empty to follow the DSH default) */
  model: string;
  provider: string;
  /** strict = conservative extraction gate (task-local/system-ish output rejected); off = legacy migration replays only */
  provenanceFilter: "strict" | "off";
  /** Require verbatim evidence on every extracted memory */
  requireEvidence: boolean;
}

export interface EmbeddingConfig {
  /** OpenAI-compatible embedding endpoint; empty = keyword-only recall */
  baseUrl: string;
  /** Secret credential (role('secret') schema slot, non-defaulted; undefined = no key stored). */
  apiKey?: string;
  model: string;
  dimensions: number;
  timeoutMs: number;
}

export interface RecallConfig {
  strategy: "keyword" | "hybrid";
  maxResults: number;
  scoreThreshold: number;
  timeoutMs: number;
  /** Max characters per injected block (prevents a single injection from blowing up the context) */
  maxInjectChars: number;
  /** Relative relevance gate margin (0–1; hits must score within this fraction of the best hit) */
  relevanceMargin: number;
  /** Importance floor for contextual (non-baseline) injection hits */
  minImportance: number;
  /** Max memory blocks per turn (stacking guard; 0 = unlimited) */
  maxInjectPerTurn: number;
  embedding: EmbeddingConfig;
}

/**
 * Episode learning (Phases 1+2 slice): capture + redaction + assembly. Only these
 * three fields in THIS slice; the plan adds review/recall/skill fields in later
 * phases (see docs/episode-learning-implementation-plan.md).
 */
export interface EpisodeLearningConfig {
  /** Master switch for episode capture/assembly (off = no episode events captured) */
  enabled: boolean;
  /** In this slice capture is gated together with this flag (episodeCtl.enabled); off = nothing captured */
  captureArguments: boolean;
  /** Redacted argument/result bound in characters (also the residual-exposure bound) */
  resultExcerptChars: number;
  /** Episodes + audit rows older than this many days are purged (bounded growth; 7–365, default 90) */
  retentionDays: number;
  /** Phase 3: LLM outcome review of assembled episodes (off = no memories learned, episodes stay unreviewed) */
  reviewEnabled: boolean;
  /** Minimum reviewer confidence for a memory to be stored (0–1, default 0.8) */
  confidenceFloor: number;
  /** Expiry of derived operational memories in days (7–365, default 90) */
  expiryDays: number;
  /** Phase 4: separately-gated operational recall injection (off = rollout default) */
  operationalRecallEnabled: boolean;
  /** Operational hits per injection (1–10, default 2) */
  maxRecallResults: number;
  /** Character cap of the operational fence itself (100–5000, default 600) */
  maxRecallChars: number;
  /** Phase 5: minimum reviewed-successful-episode group size for automatic skill synthesis (2–10, default 2) */
  skillMinEpisodes: number;
}

export interface ConsolidateConfig {
  scenesEnabled: boolean;
  sceneMaxMemories: number;
  personaMaxMemories: number;
  sceneBatchSize: number;
}

export interface EvolveConfig {
  decay: { enabled: boolean; minAgeDays: number; threshold: number; retentionDays: number; maxActiveMemories: number };
  skillSynthesis: { enabled: boolean; minImportance: number; skillsRoot: string; prefix: string; maxSkills: number };
}

export interface HousekeepingConfig {
  personaVersions: number;
  maxScenes: number;
  sceneActiveRatio: number;
  conversationRetentionDays: number;
}

export interface ReviewConfig {
  enabled: boolean;
  time: string;
}

export interface Config {
  /** L1 master switch: turn off/on at any time, hot-switched, no restart */
  enabled: boolean;
  /** Probe/debug logging */
  debug: boolean;
  /** Memory store root directory; empty = $DSH_HOME/memory; INIT-ONLY (restart on change) */
  storageRoot: string;
  /** Default number of results returned by tools */
  searchLimit: number;
  /** L2 module switches */
  modules: ModuleSwitches;
  /** L1 extraction pipeline parameters */
  extract: ExtractConfig;
  /** M3 recall parameters */
  recall: RecallConfig;
  /** M4 consolidation (L2/L3) parameters */
  consolidate: ConsolidateConfig;
  /** M4 self-evolution parameters */
  evolve: EvolveConfig;
  /** M6 growth governance: caps and cleanup for persona versions/scenes/conversation slices */
  housekeeping: HousekeepingConfig;
  /** M6 nightly review schedule: run one full evolution at a fixed time every day (extraction drain + consolidation + skills + governance) */
  review: ReviewConfig;
  /** Episode learning (capture/assembly; later phases add review/recall/skill fields) */
  episodeLearning: EpisodeLearningConfig;
}

/**
 * What the rc.2 Loader hands to apply() for this plugin's Config: every field
 * the schema declares `.volatile()` arrives as a stable Volatile ref whose
 * `.get()` reads the current validated value (see src/runtime-config.ts for
 * the policy). `storageRoot` stays nonvolatile on purpose (init-only; a
 * change must restart the fiber and close/reopen the store under drain).
 */
export interface RuntimeConfig {
  enabled: Volatile<boolean>;
  debug: Volatile<boolean>;
  storageRoot: string;
  searchLimit: Volatile<number>;
  modules: Volatile<ModuleSwitches>;
  extract: Volatile<ExtractConfig>;
  recall: Volatile<RecallConfig>;
  consolidate: Volatile<ConsolidateConfig>;
  evolve: Volatile<EvolveConfig>;
  housekeeping: Volatile<HousekeepingConfig>;
  review: Volatile<ReviewConfig>;
  episodeLearning: Volatile<EpisodeLearningConfig>;
}

// Shared LLM caller (used by extraction/consolidation/skill synthesis; reuses the DSH model stack).
// maxTokens may be a getter so settings hot-apply takes effect per call instead
// of being captured at creation time.
export function makeLlmCall(
  ctx: Context,
  config: Config,
  /** Plugin-internal audit label only; NEVER sent to the model. rc.2's wire `purpose` is reserved for `compaction | session-title`. */
  purpose: string,
  maxTokens: number | (() => number),
): (input: { system: string; user: string; sessionId?: string; signal: AbortSignal }) => Promise<string> {
  return async (input: { system: string; user: string; sessionId?: string; signal: AbortSignal }): Promise<string> => {
      const maxOutputTokens = typeof maxTokens === "function" ? maxTokens() : maxTokens;
      const assembler = new BlockAssembler();
      // Auxiliary one-shot request: identity-free user input, system prompt in
      // the system slot. `provider`/`model` must resolve clearly — extraction,
      // consolidation, review, and skill work never silently ride the wrong
      // route, and an unconfigured route fails loudly instead of guessing.
      const { provider, model } = resolveAuxModelRoute(ctx, config);
      const options: GenerateOptions = {
        messages: [
          createUserMessage({
            content: [{ type: "text", text: input.user }],
            source: { kind: "dsh-self-improved" },
          }),
        ],
        system: input.system,
        maxTokens: maxOutputTokens,
        provider,
        model,
        signal: input.signal,
      };
      if (input.sessionId) options.sessionId = input.sessionId as GenerateOptions["sessionId"];
      // Terminal-finish validation: ONLY an explicit `stop` finish yields
      // completed text for these tool-less auxiliary reviews; `tool-calls`,
      // `max-tokens`, `aborted`, `error`, unknown reasons, and a truncated
      // stream (no finish chunk) must all fail rather than feed partial
      // reviews back (evaluateTerminalFinish implements the matrix).
      let finishKind: string | null = null;
      // Cancelled-before-start: a lane signal (per-call timeout ⊕ shutdown
      // deadline, src/shutdown-v02.ts combineAbortSignals) that is already
      // aborted must not even open a doomed provider stream.
      input.signal.throwIfAborted();
      for await (const chunk of ctx.llm.stream(options)) {
        input.signal.throwIfAborted();
        assembler.push(chunk);
        if (chunk.type === "finish") finishKind = chunk.reason.kind;
      }
      input.signal.throwIfAborted();
      const verdict = evaluateTerminalFinish(finishKind ?? "absent", finishKind !== null);
      if (verdict.blocked) {
        throw new Error(`[dsh-self-improved] ${purpose}: incomplete model response (finish reason: ${verdict.kind}); not accepted as a completed review`);
      }
      const text = assembler
        .blocks()
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("");
      if (!text.trim()) {
        throw new Error(`[dsh-self-improved] ${purpose}: model returned no text`);
      }
      return text;
    };
}

/**
 * Resolve the concrete aux-call model route. Explicit plugin config wins
 * (correct for a dedicated memory model); otherwise the host default model
 * selection is used when the host provides it; otherwise the call fails
 * visibly. MIGRATION-V0.2.md excludes any provider fallback guessing.
 */
function resolveAuxModelRoute(ctx: Context, config: Config): { provider: string; model: string } {
  let provider = config.extract.provider?.trim() ?? "";
  let model = config.extract.model?.trim() ?? "";
  if (provider && model) return { provider, model };
  try {
    const selection = (ctx as CordisContext).agentDefaultModel?.currentSelection?.();
    if (selection && typeof selection.provider === "string" && typeof selection.model === "string") {
      provider = provider || selection.provider;
      model = model || selection.model;
    }
  } catch {
    /* stay unconfigured when there is no default model service */
  }
  if (!provider) {
    throw new Error(
      "dsh-self-improved: no model provider configured — set extract.provider/extract.model (e.g. provider 'go-opencode', model 'glm-5.3-flash')",
    );
  }
  if (!model) {
    throw new Error(`dsh-self-improved: model provider '${provider}' selected but extract.model is empty`);
  }
  return { provider, model };
}
/**
 * Plugin Config schema (rc.2).
 *
 * MIGRATION-V0.2.md Phase A acceptance scope: editable fields are EXPLICITLY
 * volatile (`.volatile()` markers below) so a settings edit commits into the
 * running fiber's volatile refs and emits `loader/volatile-update` instead of
 * remounting the plugin; `storageRoot` stays nonvolatile so a storage-root
 * change still owns the full restart lifecycle (store close under drain).
 * The embedding API key is a schema-declared SECRET (`role('secret')`): wire
 * reads return the redacted view plus a presence-only sidecar
 * (`SettingsNamespaceView.secrets`), so UI drafts never receive the value.
 */
export const Config = z.object({
  enabled: z.boolean().default(true).volatile(),
  debug: z.boolean().default(false).volatile(),
  // INIT-ONLY: deliberately nonvolatile — see src/runtime-config.ts policy.
  storageRoot: z.string().default(""),
  searchLimit: z.number().min(1).max(50).default(5).volatile(),
  modules: z.object({
    capture: z.boolean().default(true),
    extract: z.boolean().default(true),
    consolidate: z.boolean().default(true),
    evolve: z.boolean().default(true),
    recall: z.boolean().default(true),
    tools: z.boolean().default(true),
  }).volatile(),
  extract: z.object({
    intervalMinutes: z.number().min(1).default(15),
    batchMaxChars: z.number().min(2000).max(100000).default(12000),
    maxOutputTokens: z.number().min(128).default(2000),
    timeoutMs: z.number().min(5000).default(60000),
    dedup: z.boolean().default(true),
    fallbackOnBadJson: z.boolean().default(false),
    minImportance: z.number().min(1).max(10).default(6),
    flushDrain: z.boolean().default(false),
    model: z.string().default(""),
    provider: z.string().default(""),
    provenanceFilter: z.string().default("strict"),
    requireEvidence: z.boolean().default(true),
  }).volatile(),
  recall: z.object({
    strategy: z.string().default("keyword"),
    maxResults: z.number().min(1).max(20).default(5),
    scoreThreshold: z.number().default(0),
    timeoutMs: z.number().min(1000).default(5000),
    maxInjectChars: z.number().min(100).default(800),
    relevanceMargin: z.number().min(0).max(1).default(0.5),
    minImportance: z.number().min(0).max(10).default(0),
    maxInjectPerTurn: z.number().min(0).max(20).default(4),
    embedding: z.object({
      baseUrl: z.string().default(""),
      // SECRET SLOT: present-but-redacted on every wire read; consumers write
      // it through settings mutates, never echo it back into drafts.
      // NO default: a defaulted secret value sits in every composed namespace
      // view, and the host presence walker (`set: value !== void 0`,
      // dsh-settings redact.walk) would then report a phantom "key stored"
      // even with nothing stored (observed in the mounted describe mirror).
      // Absent value = no key; presence-only display stays truthful.
      apiKey: z.string().role("secret"),
      model: z.string().default(""),
      dimensions: z.number().min(64).default(1024),
      timeoutMs: z.number().min(1000).default(10000),
    }),
  }).volatile(),
  consolidate: z.object({
    scenesEnabled: z.boolean().default(false),
    sceneMaxMemories: z.number().min(1).default(50),
    personaMaxMemories: z.number().min(1).default(30),
    sceneBatchSize: z.number().min(1).max(20).default(8),
  }).volatile(),
  evolve: z.object({
    decay: z.object({
      enabled: z.boolean().default(true),
      minAgeDays: z.number().min(1).default(7),
      threshold: z.number().min(0).default(2),
      retentionDays: z.number().min(0).default(180),
      maxActiveMemories: z.number().min(0).default(500),
    }),
    skillSynthesis: z.object({
      enabled: z.boolean().default(false),
      minImportance: z.number().min(1).max(10).default(7),
      skillsRoot: z.string().default(""),
      prefix: z.string().default("dsi-"),
      maxSkills: z.number().min(0).default(100),
    }),
  }).volatile(),
  housekeeping: z.object({
    personaVersions: z.number().min(1).default(10),
    maxScenes: z.number().min(1).default(50),
    sceneActiveRatio: z.number().min(0).max(1).default(0.3),
    conversationRetentionDays: z.number().min(0).default(90),
  }).volatile(),
  review: z.object({
    enabled: z.boolean().default(true),
    time: z.string().default("22:00"),
  }).volatile(),
  episodeLearning: z.object({
    enabled: z.boolean().default(false),
    captureArguments: z.boolean().default(true),
    resultExcerptChars: z.number().min(200).max(50000).default(4000),
    retentionDays: z.number().min(7).max(365).default(90),
    reviewEnabled: z.boolean().default(true),
    confidenceFloor: z.number().min(0).max(1).default(0.8),
    expiryDays: z.number().min(7).max(365).default(90),
    operationalRecallEnabled: z.boolean().default(false),
    maxRecallResults: z.number().min(1).max(10).default(2),
    maxRecallChars: z.number().min(100).max(5000).default(600),
    skillMinEpisodes: z.number().min(2).max(10).default(2),
  }).volatile(),
});

/**
 * Build the plugin's plain live-view over the volatile refs the Loader handed
 * to apply(). Refs stay owned by the loader; consumers receive this mutable
 * plain object and every volatile update commits INTO it in place (same
 * nested object identities), so closures that read properties at call time
 * stay fresh and closures that captured objects keep working.
 */
export function unwrapRuntimeConfig(raw: RuntimeConfig): Config {
  return {
    enabled: readValue(raw.enabled),
    debug: readValue(raw.debug),
    storageRoot: raw.storageRoot,
    searchLimit: readValue(raw.searchLimit),
    modules: { ...readValue(raw.modules) },
    extract: { ...readValue(raw.extract) },
    recall: { ...readValue(raw.recall), embedding: { ...readValue(raw.recall).embedding } },
    consolidate: { ...readValue(raw.consolidate) },
    evolve: { decay: { ...readValue(raw.evolve).decay }, skillSynthesis: { ...readValue(raw.evolve).skillSynthesis } },
    housekeeping: { ...readValue(raw.housekeeping) },
    review: { ...readValue(raw.review) },
    episodeLearning: { ...readValue(raw.episodeLearning) },
  };
}

/** Commit one volatile update in place (same nested live object identities).
 *  Volatile snapshots are recursively FROZEN: each group is copied through
 *  `assignPlainTree` (src/runtime-config.ts) so the owned live view stays
 *  mutable and nested references (recall.embedding, evolve.*) are updated in
 *  place. A shallow Object.assign proved to break the NEXT hot edit with a
 *  read-only TypeError against the genuine Loader. */
function commitVolatileUpdate(live: Config, raw: RuntimeConfig): void {
  Object.assign(live, {
    enabled: readValue(raw.enabled),
    debug: readValue(raw.debug),
    searchLimit: readValue(raw.searchLimit),
  });
  assignPlainTree(live.modules, readValue(raw.modules));
  assignPlainTree(live.extract, readValue(raw.extract));
  assignPlainTree(live.recall, readValue(raw.recall));
  assignPlainTree(live.consolidate, readValue(raw.consolidate));
  assignPlainTree(live.evolve, readValue(raw.evolve));
  assignPlainTree(live.housekeeping, readValue(raw.housekeeping));
  assignPlainTree(live.review, readValue(raw.review));
  assignPlainTree(live.episodeLearning, readValue(raw.episodeLearning));
}

export function apply(ctx: Context, rawConfig: RuntimeConfig): void {
  // Live config view (updated in place by the volatile-update hook below —
  // closed-over objects keep working because the plugin's config shape is
  // stable and leaf objects are never replaced).
  const config: Config = unwrapRuntimeConfig(rawConfig);
  const log = (...args: unknown[]): void => {
    if (config.debug) console.log("[dsh-self-improved]", ...args);
  };

  // ① Settings page policy (rc.2): Config comes from the Loader entry.
  //    Editable fields are VOLATILE (see Config schema + runtime-config.ts):
  //    a settings edit commits into `config` in place and emits
  //    `loader/volatile-update`; the hook below re-applies hot state
  //    (schedulers, consent gate, tools/commands) without remounting.
  //    `storageRoot` stays nonvolatile: changing it restarts this fiber —
  //    unload runs every effect-owned disposer incl. the store close, and
  //    apply() re-runs with the new validated init-only config.
  // Effect-owned: the page-policy disposer runs on fiber unload (config change restart or disable).
  ctx.effect(
    () => {
      try {
        return ctx.settings.configure({ auto: true });
      } catch (error) {
        console.warn("[dsh-self-improved] settings page policy registration unavailable:", String(error));
        return () => {};
      }
    },
    "settings page policy",
  );
  log("settings page policy registered (volatile fields hot-apply; storageRoot is init-only)");

  // Runtime mutable state (M5): master/module switches read the live view;
  // the volatile-update hook re-derives everything below when the user edits
  // settings. No mutation-mirroring scope.watch path remains (rc.2 has none).
  const readModule = (m: keyof ModuleSwitches): boolean => !shuttingDown && config.enabled && config.modules[m];
  /** Init-only skills root (see runtime-config.ts INIT_ONLY_PATHS): resolved
   *  ONCE at plugin start; every consumer reads this captured value so a live
   *  edit can never retarget where synthesis/rollback writes. */
  const skillsRootInit = (config.evolve.skillSynthesis.skillsRoot ?? "").trim();
  const skillsRootLive = (): string => skillsRootInit;
  /**
   * Lifecycle boundary (Phase A): once shutdown begins, EVERY owned pipeline
   * ingress refuses new work and every already-accepted job is tracked so the
   * close disposer joins them (bounded) before `store.close()`. This is the
   * ordering that fixes the runtime-report race D1: an accepted flush
   * extraction insert was losing to `store.close()` (`database is not open`)
   * because the old teardown cleared timers and closed the store while the
   * capture/flush listener was still registered and pumps were untracked.
   */
  let shuttingDown = false;
  /** Currently accepted background jobs (extraction pumps, reviews, evolution rounds). */
  const acceptedJobs = new Set<Promise<unknown>>();
  /**
   * Owned shutdown deadline cancellation (src/shutdown-v02.ts): the drain's
   * `cancel()` hook aborts this controller AT THE DEADLINE, and every accepted
   * auxiliary LLM lane unions the signal into its real request path with
   * `combineAbortSignals(perCallSignal, shutdownDeadlineGate.signal)` — the
   * genuine `GenerateOptions.signal` transport, not a warning-only path.
   */
  const shutdownDeadlineGate = new AbortController();
  const trackAcceptedJob = <T,>(job: Promise<T>): Promise<T> => {
    // Settle-tracking without ever "handling" the job's own rejection: the
    // first real consumer (flush barrier / command / review runner) still
    // observes the failure; the drain only counts/settles it.
    void Promise.resolve(job).finally(() => {
      acceptedJobs.delete(job);
      return undefined;
    }).catch(() => {});
    acceptedJobs.add(job);
    return job;
  };
  /** Everything that must follow a hot settings edit WITHOUT a restart. */
  const applyHotSettingsUpdate = (): void => {
    // Init-only filesystem root enforcement (skillsRoot): the loader CAN carry
    // a live edit through its volatile group, but the plugin keeps the startup
    // value effective — a live write never retargets a running filesystem root.
    const liveSkillsRoot = (config.evolve.skillSynthesis.skillsRoot ?? "").trim();
    if (liveSkillsRoot !== skillsRootInit) {
      console.warn(
        "[dsh-self-improved] evolve.skillSynthesis.skillsRoot is initialization-only; the running fiber keeps",
        JSON.stringify(skillsRootInit), "— restart to apply", JSON.stringify(liveSkillsRoot),
      );
    }
    // Consent recheck at the authoritative boundary: toggling the review
    // Consent recheck at the authoritative boundary: toggling the review
    // switch off cancels pending review work besides ceasing eligibility.
    episodeReviewGate.setEnabled(config.enabled && episodeState.enabled && episodeState.reviewEnabled);
    syncSchedulers();
    syncTools();
    syncCommands();
  };
  ctx.on("loader/volatile-update", () => {
    if (shuttingDown) return;
    try {
      commitVolatileUpdate(config, rawConfig);
    } catch (error) {
      console.warn("[dsh-self-improved] volatile config commit failed:", String(error));
      return;
    }
    try {
      applyHotSettingsUpdate();
    } catch (error) {
      console.warn("[dsh-self-improved] hot settings reapplication failed:", String(error));
    }
    log("volatile settings applied (no restart)");
  });

  // ② Memory store (M1): SQLite + FTS5 + sqlite-vec skeleton
  const dir = config.storageRoot.trim() || defaultMemoryDir();
  const store = new MemoryStore(dir);
  // Episode-side consistency repair is idempotent (same discipline as repairConsistency)
  try {
    repairEpisodeConsistency(store);
  } catch (error) {
    console.warn("[dsh-self-improved] episode consistency repair failed:", String(error));
  }
  // Startup recovery: stranded episode events (e.g. a previous process died
  // between append and assembly, or assembly was skipped) are re-assembled.
  for (const sessionId of store.sessionsWithPendingEpisodeEvents(500)) {
    try {
      assembleSessionEpisodes(store, sessionId);
    } catch (error) {
      console.warn("[dsh-self-improved] startup episode assembly failed:", sessionId, String(error));
    }
  }
  log("memory store ready:", dir);

  // Hermes-style durable baseline: a small curated profile belongs in the
  // system prompt, not after the current request as another user-role message.
  // Contextual/project recall remains a separately labeled runtime snapshot.
  ctx.systemPrompt.section({
    name: "dsh-self-improved:curated-profile",
    order: 20,
    text: () => (readModule("recall") ? renderCuratedProfile(store, 2400) : ""),
  });

  // ③ L0 capture + L1 extraction: persist slices and mark the queue inside session/flush barriers;
  //    in headless mode (flushDrain) drain extraction synchronously so the 5s shutdown timeout does not kill the pipeline.
  // Extraction settings as a LIVE view over `config`: volatile edits reach the
  // running extractor without restart, so every field is read at call time.
  const extractSettings: ExtractSettings = {
    get enabled() { return readModule("extract"); },
    get intervalMinutes() { return config.extract.intervalMinutes; },
    get batchMaxChars() { return config.extract.batchMaxChars; },
    get maxOutputTokens() { return config.extract.maxOutputTokens; },
    get timeoutMs() { return config.extract.timeoutMs; },
    get dedup() { return config.extract.dedup; },
    get fallbackOnBadJson() { return config.extract.fallbackOnBadJson; },
    get minImportance() { return config.extract.minImportance; },
    get flushDrain() { return config.extract.flushDrain; },
    get provenanceFilter() { return (config.extract.provenanceFilter === "off" ? "off" : "strict") as "off" | "strict"; },
    get requireEvidence() { return config.extract.requireEvidence; },
    projectId: "",
    projectIdForSession: (sessionId) => store.getSessionProject(sessionId),
  };
  // Embedding settings are read at call time as well (secret slot included);
  // createOpenAiEmbedding keeps the live object reference.
  const embeddingProvider = createOpenAiEmbedding(config.recall.embedding);

  const extractLlm = makeLlmCall(ctx, config, "memory-extract", () => extractSettings.maxOutputTokens);

  const extractor = new Extractor(store, extractSettings, async ({ system, user, sessionId, signal }) => {
    if (config.debug) {
      console.log("[dsh-self-improved] extract llm input:", typeof user, "len:", String(user).length, "session:", sessionId);
    }
    // Auxiliary cancellation is REAL: the extractor's per-call timeout signal
    // is united with the owned shutdown deadline signal, so drain-deadline
    // abort reaches ctx.llm.stream through GenerateOptions.signal (the
    // rc.2 adapter contract), not merely a console warning.
    return extractLlm({ system, user, sessionId, signal: combineAbortSignals(signal, shutdownDeadlineGate.signal) });
  }, embeddingProvider);
  // Episode-learning runtime state as a LIVE view over config (volatile edits
  // reach capture/review/recall/skill gates without a restart).
  const episodeState = {
    get enabled() { return config.episodeLearning.enabled; },
    get captureArguments() { return config.episodeLearning.captureArguments; },
    get maxChars() { return config.episodeLearning.resultExcerptChars; },
    get reviewEnabled() { return config.episodeLearning.reviewEnabled; },
    get confidenceFloor() { return config.episodeLearning.confidenceFloor; },
    get expiryDays() { return config.episodeLearning.expiryDays; },
    get operationalRecallEnabled() { return config.episodeLearning.operationalRecallEnabled; },
    get maxRecallResults() { return config.episodeLearning.maxRecallResults; },
    get maxRecallChars() { return config.episodeLearning.maxRecallChars; },
    get skillMinEpisodes() { return config.episodeLearning.skillMinEpisodes; },
  };
  const episodeReviewGate = new EpisodeReviewAbortGate();
  episodeReviewGate.setEnabled(config.enabled && episodeState.enabled && episodeState.reviewEnabled);
  // Ingress (L0): the capture/flush listener. The accepted pump is TRACKED so
  // shutdown can drain it before store.close(); readModule()'s shuttingDown
  // gate refuses new capture work once shutdown starts.
  const captureDispose = installCapture(ctx, store, { enabled: () => readModule("capture") }, () => {
    if (!extractSettings.enabled) return undefined;
    const pumpJob = trackAcceptedJob(extractor.pump());
    if (!extractSettings.flushDrain) {
      void pumpJob.catch((error) => console.warn("[dsh-self-improved] extract pump error:", String(error)));
      return undefined;
    }
    // flushDrain: the flush barrier awaits THIS promise — the same tracked job
    // that the shutdown drain joins, so the flush's own accepted extraction
    // commits before the teardown's store close.
    return pumpJob;
  }, {
    enabled: () => readModule("capture") && episodeState.enabled && episodeState.captureArguments,
    maxChars: () => episodeState.maxChars,
  });
  log("capture + extract installed");

  // Timed evolution pipeline (dsh-schedule is not part of the headless base assembly, so in-process timers are used)
  const consolidateLlm = makeLlmCall(ctx, config, "memory-consolidate", 2000);
  // Live view again: consolidation defaults follow volatile edits without restart.
  const consolidateSettings = {
    get scenesEnabled() { return config.consolidate.scenesEnabled; },
    get sceneMaxMemories() { return config.consolidate.sceneMaxMemories; },
    get personaMaxMemories() { return config.consolidate.personaMaxMemories; },
    get sceneBatchSize() { return config.consolidate.sceneBatchSize; },
  };
  const consolidator = new Consolidator(
    store,
    consolidateSettings,
    async ({ system, user, signal }) =>
      consolidateLlm({ system, user, signal: combineAbortSignals(signal, shutdownDeadlineGate.signal) }),
    embeddingProvider,
  );
  const skillLlm = makeLlmCall(ctx, config, "memory-skill", 3000);
  const episodeReviewLlm = makeLlmCall(ctx, config, "episode-review", 2000);
  const episodeSkillLlm = makeLlmCall(ctx, config, "episode-skill", 3000);
  let lastEvolveTs = 0;
  /**
   * Run one evolution round.
   * heavy=true: run consolidation + skills (heavy LLM work) — for nightly review / manual / startup backfill;
   * heavy=false: only free maintenance (decay + governance) — used by the 15-minute timer round.
   * force=true: ignore the "no new memories" skip condition (manual/nightly/startup).
   */
  const runEvolution = async (force: boolean, heavy = true): Promise<Record<string, unknown>> => {
    const summary: Record<string, unknown> = { forced: force, heavy };
    const jobs: Array<Promise<unknown>> = [];
    const newest = store.newestMemoryTs();
    const hasNew = newest > lastEvolveTs;
    const doHeavy = heavy && (force || hasNew) && (readModule("consolidate") || readModule("evolve"));
    if (doHeavy && readModule("consolidate")) {
      jobs.push(
        consolidator.consolidate().then((r) => { summary.consolidate = r; }).catch((e) => console.warn("[dsh-self-improved] consolidate error:", String(e))),
      );
    }
    if (doHeavy && readModule("evolve")) {
      jobs.push(
        synthesizeSkills(
          store,
          async ({ system, user, signal }) =>
            skillLlm({ system, user, signal: combineAbortSignals(signal, shutdownDeadlineGate.signal) }),
          {
            enabled: config.evolve.skillSynthesis.enabled,
            minImportance: config.evolve.skillSynthesis.minImportance,
            skillsRoot: skillsRootLive(),
            prefix: config.evolve.skillSynthesis.prefix,
            maxSkills: config.evolve.skillSynthesis.maxSkills,
          },
          skillsRootLive(),
        )
          .then((n) => { summary.skills = n; if (n > 0) log("skills synthesized:", n); })
          .catch((e) => console.warn("[dsh-self-improved] skill synthesis error:", String(e))),
      );
    }
    if (heavy && !doHeavy) summary.skipped = "no new memories";
    // Free maintenance: decay + growth governance (no LLM, runs every round)
    jobs.push(
      Promise.resolve()
        .then(() =>
          applyDecay(store, {
            enabled: config.evolve.decay.enabled,
            minAgeDays: config.evolve.decay.minAgeDays,
            threshold: config.evolve.decay.threshold,
            retentionDays: config.evolve.decay.retentionDays,
            maxActiveMemories: config.evolve.decay.maxActiveMemories,
          }),
        )
        .then((r) => { summary.decay = r; if (r.decayed > 0 || r.deleted > 0) log("decay applied:", JSON.stringify(r)); })
        .catch((e) => console.warn("[dsh-self-improved] decay error:", String(e))),
    );
    jobs.push(
      Promise.resolve()
        .then(() => {
          const g = {
            personaVersions: store.prunePersonaVersions(config.housekeeping.personaVersions),
            scenes: store.pruneScenes(config.housekeeping.maxScenes, config.housekeeping.sceneActiveRatio),
            slices: store.pruneConversationSlices(Date.now() - config.housekeeping.conversationRetentionDays * 86_400_000),
          };
          if (g.personaVersions > 0 || g.scenes > 0 || g.slices > 0) log("housekeeping:", JSON.stringify(g));
          return g;
        })
        .then((g) => { summary.housekeeping = g; })
        .catch((e) => console.warn("[dsh-self-improved] housekeeping error:", String(e))),
    );
    await Promise.allSettled(jobs);
    if (newest > 0) lastEvolveTs = newest;
    return summary;
  };
  // Full review: drain pending extraction + full evolution (consolidation/skills/decay/governance)
  const fullReview = async (reason: string): Promise<Record<string, unknown>> => {
    const pumped = await extractor.pump().catch((e) => {
      console.warn("[dsh-self-improved] review pump error:", String(e));
      return { sessions: 0, memories: 0, skipped: 0, errors: 1 };
    });
    const episodeReviewPromise =
      config.enabled && episodeState.enabled && episodeState.reviewEnabled
        ? runEpisodeReview(
            store,
            // The scheduled/manual lane shares the SAME per-call aux transport
            // (deadline ⊕ per-call timeout) but has NO per-request carrier: its
            // lane signal stays the consent gate — shared command/no-carrier
            // review behavior is unchanged apart from the new per-call bound.
            episodeReviewAuxCall,
            {
              confidenceFloor: episodeState.confidenceFloor,
              expiryDays: episodeState.expiryDays,
            },
            episodeReviewGate.getSignal(),
          )
            .then((s) => { log("episode review:", JSON.stringify(s)); return s; })
            .catch((e) => console.warn("[dsh-self-improved] episode review error:", String(e)))
        : null;
    const summary = await runEvolution(true, true);    if (episodeReviewPromise) await episodeReviewPromise;
    // Phase 5 (OPT-IN, runs only from fullReview — never per-flush): episode-to-skill
    // synthesis needs the Phase 3 review to have committed its derived memories first.
    if (
      readModule("evolve") &&
      episodeState.enabled &&
      config.evolve.skillSynthesis.enabled
    ) {
      try {
        const n = await synthesizeSkillsFromEpisodes(
          store,
          async ({ system, user, signal }) => episodeSkillLlm({ system, user, signal }),
          {
            skillsRoot: skillsRootLive(),
            prefix: config.evolve.skillSynthesis.prefix,
            maxSkills: config.evolve.skillSynthesis.maxSkills,
            minEpisodes: episodeState.skillMinEpisodes,
          },
        );
        if (n > 0) log("episode skills synthesized:", n);
        summary.episodeSkills = n;
      } catch (e) {
        console.warn("[dsh-self-improved] episode skill synthesis error:", String(e));
      }
    }
    log(`review(${reason}) done:`, JSON.stringify({ pumped, ...summary }));
    return { pumped, ...summary };
  };

  // Unified timer management: follows the master switch — off stops all timers immediately, on re-arms them automatically
  let timer: NodeJS.Timeout | undefined;
  let reviewTimer: NodeJS.Timeout | undefined;
  let startupTimer: NodeJS.Timeout | undefined;
  let startupReviewDone = false;

  const parseHHMM = (s: string): number => {
    const m = /^(\d{1,2}):(\d{2})$/.exec(s.trim());
    if (!m) return 22 * 3_600_000; // fall back to 22:00 on invalid config
    return Number(m[1]) * 3_600_000 + Number(m[2]) * 60_000;
  };

  // 15-minute round: only "extraction + free maintenance", no heavy LLM work (evolution is left to nightly review / manual / startup backfill)
  const armMaintenanceTimer = (): void => {
    if (timer) clearInterval(timer);
    timer = undefined;
    if (!config.enabled) return;
    timer = setInterval(() => {
      trackAcceptedJob(
        extractor
          .pump()
          .then(() => runEvolution(false, false))
        .then((s) => {
          if (s.skipped) log("maintenance round (no heavy work)");
          // Stale pending episodes: never assembled in-window → ambiguous (never learned from)
          if (config.enabled && episodeState.enabled) {
            // Starvation recovery: stranded pending events get re-assembled here too
            try {
              for (const sessionId of store.sessionsWithPendingEpisodeEvents(500)) {
                assembleSessionEpisodes(store, sessionId);
              }
            } catch (e) {
              console.warn("[dsh-self-improved] maintenance episode assembly error:", String(e));
            }
            const closed = closeStalePendingEpisodes(store, 30 * 60_000);
            if (closed > 0) log("stale pending episodes closed:", closed);
            // Retention: bound episode/evidence growth to retentionDays
            try {
              const cutoff = Date.now() - config.episodeLearning.retentionDays * 86_400_000;
              const purged = store.purgeEpisodes({ olderThanTs: cutoff });
              const total = purged.episodes + purged.steps + purged.events;
              if (total > 0) log("episode retention purge:", JSON.stringify(purged));
            } catch (e) {
              console.warn("[dsh-self-improved] episode retention purge error:", String(e));
            }
          }
        })
        .catch((e) => console.warn("[dsh-self-improved] extract pump error:", String(e))),
      );
    }, config.extract.intervalMinutes * 60_000);
    timer.unref?.();
  };

  // Nightly review: run once a day at config.review.time (default 22:00); re-arm for the next day after it completes
  const armNightlyReview = (): void => {
    if (reviewTimer) clearTimeout(reviewTimer);
    reviewTimer = undefined;
    if (!config.enabled || !config.review.enabled) return;
    const hhmm = parseHHMM(config.review.time);
    const now = new Date();
    const target = new Date(now);
    target.setHours(0, 0, 0, 0);
    target.setTime(target.getTime() + hhmm);
    let diff = target.getTime() - now.getTime();
    if (diff <= 0) diff += 24 * 3_600_000;
    reviewTimer = setTimeout(() => {
      trackAcceptedJob(
        fullReview("nightly")
          .catch((e) => console.warn("[dsh-self-improved] nightly review error:", String(e)))
          .finally(() => armNightlyReview()),
      );
    }, diff);
    reviewTimer.unref?.();
    log("nightly review armed at", config.review.time, "(in", Math.round(diff / 60_000), "min)");
  };

  // Startup backfill: ~60s after boot, run one full review if there are active memories (no data lost on restart, no waiting for nighttime); runs only once
  const armStartupReview = (): void => {
    if (startupTimer) clearTimeout(startupTimer);
    startupTimer = undefined;
    if (startupReviewDone || !config.enabled) return;
    if (store.newestMemoryTs() <= 0) return;
    startupTimer = setTimeout(() => {
      startupReviewDone = true;
      trackAcceptedJob(
        fullReview("startup").catch((e) => console.warn("[dsh-self-improved] startup review error:", String(e))),
      );
    }, 60_000);
    startupTimer.unref?.();
  };

  const syncSchedulers = (): void => {
    armMaintenanceTimer();
    armNightlyReview();
    armStartupReview();
  };
  syncSchedulers();
  log("schedulers armed (15min maintenance, nightly review, 60s startup backfill); disabling master switch stops all timers");

  // ④ Memory tools (M1/M4): runtime-toggleable (tools module)
  let toolsDispose: (() => void) | null = null;
  const syncTools = (): void => {
    const want = readModule("tools");
    if (want && !toolsDispose) {
      toolsDispose = registerMemoryTools(ctx, store, config.searchLimit, {
        confidenceFloor: () => episodeState.confidenceFloor,
        maxResults: () => episodeState.maxRecallResults,
      // SHARED LANE: the model's memory_forget runs the SAME single-owner
      // policy boundary as the browser remote and /memory forget (command
      // caller lane). Resolved per call, so a later-created businessApi counts.
      }, () => {
        if (!businessApi) return null;
        return (id: string) =>
          businessApi!.forget({ peerId: null, source: "command" }, id, { token: "" }, undefined);
      });
      log("tools enabled");
    } else if (!want && toolsDispose) {
      toolsDispose();
      toolsDispose = null;
      log("tools disabled");
    }
  };
  syncTools();

  // ⑤ Recall injection (M3): automatically inject relevant memories at agent/pre-step.
  // Scope comes directly from the event's owning Agent, never mutable cross-session state.
  const projectKeyOfAgent = (agent: unknown): string => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const cwd = (agent as any)?.session?.header?.cwd;
    return projectKeyFromCwd(typeof cwd === "string" ? cwd : "");
  };
  const sessionIdForAgent = (agent: unknown): string => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const id = (agent as any)?.id;
    return typeof id === "string" ? id : "";
  };
  // Recall settings as a LIVE view: volatile edits reach the next query.
  const rec: { recallSettings: RecallSettings } = { recallSettings: {
    get strategy() { return config.recall.strategy === "hybrid" ? ("hybrid" as const) : ("keyword" as const); },
    get maxResults() { return config.recall.maxResults; },
    get scoreThreshold() { return config.recall.scoreThreshold; },
    get timeoutMs() { return config.recall.timeoutMs; },
    get relevanceMargin() { return config.recall.relevanceMargin; },
    get minImportance() { return config.recall.minImportance; },
  } };
  const recall = new RecallService(store, rec.recallSettings, embeddingProvider);
  const injectionCtl = {
    enabled: () => readModule("recall"),
    get maxHits() { return config.recall.maxResults; },
    get maxChars() { return config.recall.maxInjectChars; },
    get debug() { return config.debug; },
    projectKeyOf: projectKeyOfAgent,
    sessionIdOf: sessionIdForAgent,
    maxInjectPerTurn: config.recall.maxInjectPerTurn,
    onInjected: (ids: string[]) => store.recordAccess(ids),
    // Phase 4: operational lane (live getters so settings hot-apply reaches each pre-step)
    operational: {
      enabled: () => readModule("recall") && episodeState.enabled && episodeState.operationalRecallEnabled,
      get maxResults() { return episodeState.maxRecallResults; },
      get maxChars() { return episodeState.maxRecallChars; },
      get confidenceFloor() { return episodeState.confidenceFloor; },
    },
  };
  installRecallInjection(ctx, recall, injectionCtl);
  log("recall injection installed (strategy:", rec.recallSettings.strategy, ", project scoping on)");

  let browserChannel: BrowserChannel | null = null;
  let businessApi: ReturnType<typeof createMemoryBusiness> | null = null;
  try {
    // The shared business API (commands+browser use the same instance); the
    // remote surface is the ONLY config-namespace-free action channel on rc.2.
    const businessDeps = {
      store,
      enabled: () => config.enabled,
      skillsPrefix: () => config.evolve.skillSynthesis.prefix,
      skillsRoot: () => skillsRootLive(),
      episodeEnabled: () => episodeState.enabled,
      deleteSkill,
      episodeDryReview: (callSignal?: AbortSignal) =>
        (!shuttingDown && episodeState.enabled && episodeState.reviewEnabled) ? episodeReviewRun(true, callSignal) : null,
      log: (...args: unknown[]): void => { if (config.debug) console.log("[dsh-self-improved]", ...args); },
    };
    businessApi = createMemoryBusiness(businessDeps);
    ctx.effect(() => {
      const businessDispose = registerMemoryBusinessRemote(ctx, businessDeps, businessApi!);
      return businessDispose;
    }, "memory business remote");
    log("memory business remote registered (selfImproved namespace)");
  } catch (error) {
    console.warn("[dsh-self-improved] business remote registration failed:", String(error));
  }

  // ⑥ CLI command (M5): /memory (active when the host provides a commands service); hot-registers/unregisters following the master switch
  // Browser channel is created below (⑧) but referenced by the episode-review
  // delegate (dry-review summaries publish into the served snapshot), so the
  // variable must exist before the command handler can run — command
  // invocations can only arrive after apply() finishes anyway.
  /**
   * The REAL aux transport of one review LLM call. `signal` is the review
   * lane's combined signal (per-call carrier cancel ⊕ consent gate). It is
   * united with the owned shutdown deadline and ONE per-call timeout abort —
   * created PER CALL so a timeout (or caller cancel) of one episode's request
   * can never abort an unrelated concurrent call — and the union reaches
   * `GenerateOptions.signal` of the genuine ctx.llm.stream request (the rc.2
   * adapter contract MUST honor it), not a post-hoc warning.
   */
  const EPISODE_REVIEW_CALL_TIMEOUT_MS = 180_000;
  const episodeReviewAuxCall = async ({ system, user, signal }: { system: string; user: string; signal: AbortSignal })=> {
    return episodeReviewLlm({
      system,
      user,
      signal: combineAbortSignals(signal, shutdownDeadlineGate.signal, AbortSignal.timeout(EPISODE_REVIEW_CALL_TIMEOUT_MS)),
    });
  };
  /** Manual/nightly episode review runner. dry=true → validateOnly commits (nothing persists).
   *  Gated on the master switch + episodeLearning.enabled + reviewEnabled; publishes the
   *  summary line into the browser snapshot so the UI can display the last verdict.
   *
   *  `callSignal` carries the RPC dryReview call's own carrier cancellation
   *  (rc.2 Gateway invocation signal forwarded by the business deps). It is
   *  UNIONED with the plugin-owned consent gate — never replacing it — so:
   *  - a per-call cancel stops ONLY that review pass (the shared consent gate
   *    is not tripped, other passes/lanes keep running);
   *  - disabling/discharging the consent gate still cancels every queued AND
   *    in-flight pass (its abort rides the same combined lane signal);
   *  - the command lane (/memory episode-review) passes no carrier and remains
   *    bounded by the gate + downstream per-call timeout exactly as before. */
  const episodeReviewRun = (dry: boolean, callSignal?: AbortSignal): Promise<EpisodeReviewSummary> => {
    if (!config.enabled || !episodeState.enabled || !episodeState.reviewEnabled) {
      return Promise.reject(
        new Error("Episode learning review is disabled (dsh-self-improved enabled / episodeLearning.enabled / reviewEnabled)"),
      );
    }
    // Already-aborted carrier passes through as the FIRST already-aborted input
    // (src/shutdown-v02.ts combineAbortSignals), so a pre-cancelled call never
    // opens review work; a mid-flight cancel aborts the pass it belongs to.
    const laneSignal = combineAbortSignals(callSignal, episodeReviewGate.getSignal());
    return trackAcceptedJob(
      runEpisodeReview(
        store,
        episodeReviewAuxCall,
        {
          confidenceFloor: episodeState.confidenceFloor,
          expiryDays: episodeState.expiryDays,
          dryRun: dry,
        },
        laneSignal,
      ).then((s) => {
        log("episode review" + (dry ? " (dry-run)" : "") + ":", JSON.stringify(s));
        try {
          browserChannel?.episodeStatus(JSON.stringify({ ...s, dryRun: dry, at: Date.now() }));
        } catch { /* status publish is best effort */ }
        return s;
      }),
    );
  };
  let commandsDispose: (() => void) | null = null;
  const syncCommands = (): void => {
    if (!config.enabled) {
      if (commandsDispose) {
        commandsDispose();
        commandsDispose = null;
        log("/memory command disabled");
      }
      return;
    }
    if (commandsDispose) return;
    commandsDispose = installMemoryCommands(ctx, store, {
      evolve: () => trackAcceptedJob(fullReview("manual")),
      isEnabled: () => config.enabled,
      // Live getters: hot-applied synthesis settings must reach `/memory browser --json`
      // and the synthesized-skill flags without re-registering the command.
      skillsPrefix: () => config.evolve.skillSynthesis.prefix,
      skillsRoot: () => skillsRootLive(),
      episodeEnabled: () => episodeState.enabled,
      episodeReview: (dry) => episodeReviewRun(dry),
      // rc.2: browse/forget/correct run the shared business lane (one
      // operation, shared with the typed browser remote).
      business: businessApi ?? undefined,
    });
    if (commandsDispose) {
      log("memory command installed (/memory)");
    } else {
      log("commands service unavailable in this host — skip /memory command");
    }
  };
  syncCommands();

  // ⑦ Hot apply (rc.2 volatile semantics): editable fields are volatile (see
  // the Config schema + runtime-config.ts policy); the `loader/volatile-update`
  // hook above commits edits into the live view and re-derives consent gates,
  // schedulers, and tools/commands registrations without a restart.
  // `storageRoot` is init-only: that edit alone still goes through the full
  // restart lifecycle above (store close under drain).

  // ⑧ Memory browser data channels.
  // ⑧a LEGACY (rc.6/rc.8 hosts): Config-namespace channel stays available only
  //    via the legacy settingsApi and remains inert on rc.2 (fail-closed
  //    scaffolding, kept for rollback/compat evidence).
  // ⑧b rc.2 channel: the typed business Remote surface (src/business.ts) —
  //    entry-addressed reads plus authorized one-shot-challenge mutating calls
  //    and cancellable model work, shared with commands/tools.
  browserChannel = installBrowserChannel({
    ctx,
    store,
    skillsPrefix: () => config.evolve.skillSynthesis.prefix,
    skillsRoot: () => skillsRootLive(),
    deleteSkill,
    episodeEnabled: () => episodeState.enabled,
    episodeDryReview: (callSignal?: AbortSignal) =>
      (!shuttingDown && episodeState.enabled && episodeState.reviewEnabled) ? episodeReviewRun(true, callSignal) : null,
    log,
  });
  log("memory browser channel installed (legacy CAM; rc.2 path is the typed business remote)");


  // ⑥ Background pipeline (from M2 on: extract/consolidate/evolve, driven by dsh-schedule)
  // Note: M0 confirmed the schedule service is not in the headless base assembly; gate on the assembly when introducing it

  log("dsh-self-improved loaded (full M5 build)");

  // ── Effect-owned lifecycle ordering (Phase A) ──────────────────────────
  // Accepted-work/shutdown contract (numbered steps documented inside
  // registerShutdownDrain): the effect is registered LAST so cordis's reverse
  // disposal order runs it FIRST on unload/restart/disable. This fixes
  // runtime-report defect D1: the old teardown closed the store while the
  // capture/flush listener was still registered and while untracked pump
  // promises were mid-flight, so an accepted flush extraction insert was lost
  // with `database is not open`. The coordinator round-59 deadline race (warn
  // → wipe the tracking set → close while accepted jobs still ran) is closed
  // by the new policy in src/shutdown-v02.ts: owned deadline cancellation,
  // retained ownership, and a storage close that fires only after every
  // accepted job in the live tracking set actually settles.
  registerShutdownDrain(ctx, {
    onShutdownStart: () => { shuttingDown = true; },
    dropIngress: () => { captureDispose(); },
    preClose: () => {
      // ③ consent gate cancels review work; timers lock out; ④ registrations.
      episodeReviewGate.abort();
      if (timer) { clearInterval(timer); timer = undefined; }
      if (startupTimer) { clearTimeout(startupTimer); startupTimer = undefined; }
      if (reviewTimer) { clearTimeout(reviewTimer); reviewTimer = undefined; }
      if (toolsDispose) { toolsDispose(); toolsDispose = null; }
      if (commandsDispose) { commandsDispose(); commandsDispose = null; }
      if (browserChannel) browserChannel.stop();
    },
    cancel: () => {
      // Deadline cancellation through the plugin's OWNED signals: the consent
      // gate stops queued/in-flight episode review work, and every other
      // accepted auxiliary LLM lane already unions its per-call timeout signal
      // with this controller (combineAbortSignals above), so the abort reaches
      // ctx.llm.stream through GenerateOptions.signal — not a warning-only path.
      shutdownDeadlineGate.abort(new Error("shutdown deadline reached: cancelling owned auxiliary work"));
    },
    jobs: acceptedJobs,
    close: () => store.close(),
    warn: (message: string) => console.warn("[dsh-self-improved]", message),
  });
}

/**
 * Phase A lifecycle boundary (accepted-work shutdown ordering) moved to
 * src/shutdown-v02.ts — the coordinator round-59 probe showed the previous
 * in-file implementation racing `Promise.allSettled` with the 5 s budget and
 * then warning/clearing the tracking set/closing the store WHILE accepted jobs
 * were still running. The bound is now SAFE: cancellation through owned
 * signals at the deadline, ownership retained until actual settlement, and a
 * store close that is deferred (never raced) underneath unsettled accepted
 * work. Re-exported unchanged so the focused suites keep binding the exact
 * symbols apply() uses (single implementation, no reimplementation).
 */
export {
  SHUTDOWN_DRAIN_BUDGET_MS,
  combineAbortSignals,
  registerShutdownDrain,
} from "./shutdown-v02.js";
export type { ShutdownDrainTarget } from "./shutdown-v02.js";
