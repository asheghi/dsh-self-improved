#!/usr/bin/env node
// Synthetic recall-boundary regressions required by Phase B. No store/provider I/O.
// Tests intentionally fail until revision invalidation and final policy checks exist.
import { installRecallInjection } from '../lib/inject.js';
let failures = 0;
const marker = 'SYNTHETIC_REVOKED_FACT';
const hit = { id: 'synthetic-memory', kind: 'fact', content: marker, importance: 7, score: 1 };
const payload = () => ({ step: 1, agent: { id: 'synthetic-session' }, signal: new AbortController().signal });
const next = async () => ({ kind: 'enter', messages: [{ role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'synthetic topic' }] }] });
function install(search, enabled = () => true) {
  let handler;
  installRecallInjection({ on(_name, fn) { handler = fn; } }, { search, searchOperational: () => [] }, {
    enabled, maxHits: 1, maxChars: 2000,
    sessionIdOf: () => 'synthetic-session', projectKeyOf: () => 'synthetic-project',
  });
  return handler;
}
function check(name, condition) {
  console.log(`${condition ? 'PASS' : 'FAIL'} ${name}`);
  if (!condition) failures++;
}
{
  let available = true;
  const handler = install(async () => available ? [hit] : []);
  const first = await handler(payload(), next);
  check('positive control: eligible fact is recalled', JSON.stringify(first.messages).includes(marker));
  available = false;
  const second = await handler(payload(), next);
  check('identical query cannot replay evidence no longer eligible', !JSON.stringify(second.messages).includes(marker));
}
{
  let corrected = false;
  const handler = install(async () => [{ ...hit, content: corrected ? 'SYNTHETIC_CORRECTED_FACT' : marker }]);
  await handler(payload(), next);
  corrected = true;
  const second = await handler(payload(), next);
  check('identical query receives corrected eligible evidence', JSON.stringify(second.messages).includes('SYNTHETIC_CORRECTED_FACT'));
}
{
  let enabled = true;
  const handler = install(async () => { enabled = false; return [hit]; }, () => enabled);
  const decision = await handler(payload(), next);
  check('pause during retrieval prevents late context admission', !JSON.stringify(decision.messages).includes(marker));
}
if (failures) process.exitCode = 1;
console.log(`Revocation boundary regressions: ${failures ? 'FAILED' : 'PASS'}`);
